<?php
namespace Aheadworks\SocialLogin\Exception;

use Magento\Framework\Exception\LocalizedException;

/**
 * Class UnknownProviderException
 */
class UnknownProviderException extends LocalizedException
{

}
