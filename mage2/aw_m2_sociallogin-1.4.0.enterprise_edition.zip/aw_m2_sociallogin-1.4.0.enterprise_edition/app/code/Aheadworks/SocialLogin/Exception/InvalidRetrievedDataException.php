<?php
namespace Aheadworks\SocialLogin\Exception;

use Magento\Framework\Exception\LocalizedException;

/**
 * Class InvalidRetrievedDataException
 */
class InvalidRetrievedDataException extends LocalizedException
{

}
