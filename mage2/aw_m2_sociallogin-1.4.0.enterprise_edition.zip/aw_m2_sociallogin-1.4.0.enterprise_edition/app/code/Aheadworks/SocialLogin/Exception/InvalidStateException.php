<?php
namespace Aheadworks\SocialLogin\Exception;

use Magento\Framework\Exception\LocalizedException;

/**
 * Class InvalidStateException
 */
class InvalidStateException extends LocalizedException
{

}
