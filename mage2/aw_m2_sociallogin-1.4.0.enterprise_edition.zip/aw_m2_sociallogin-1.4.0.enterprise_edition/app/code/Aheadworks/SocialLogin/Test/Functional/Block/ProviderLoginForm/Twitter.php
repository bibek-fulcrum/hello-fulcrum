<?php
namespace Aheadworks\SocialLogin\Test\Block\ProviderLoginForm;

use Aheadworks\SocialLogin\Test\Block\ProviderLoginForm;

/**
 * Class Twitter
 */
class Twitter extends ProviderLoginForm
{
    /**
     * @var string
     */
    protected $submitButtonSelector = 'input#allow';
}
