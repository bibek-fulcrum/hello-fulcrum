<?php
namespace Aheadworks\SocialLogin\Test\TestCase;

use Magento\Mtf\TestCase\Scenario;

/**
 * Preconditions:
 * 1. @TODO
 *
 * Steps:
 * 1. Set login block settings
 * 2. Flush cache
 * 3. Assert login block on FE
 *
 * @group @TODO
 */
class LoginBlockSettingsTest extends Scenario
{
    /**
     * Run scenario
     */
    public function test()
    {
        $this->executeScenario();
    }
}
