<?php
namespace Aheadworks\SocialLogin\Test\Block\ProviderLoginForm;

use Aheadworks\SocialLogin\Test\Block\ProviderLoginForm;

/**
 * Class Google
 */
class Google extends ProviderLoginForm
{
    /**
     * @var string
     */
    protected $submitButtonSelector = 'input#signIn';
}
