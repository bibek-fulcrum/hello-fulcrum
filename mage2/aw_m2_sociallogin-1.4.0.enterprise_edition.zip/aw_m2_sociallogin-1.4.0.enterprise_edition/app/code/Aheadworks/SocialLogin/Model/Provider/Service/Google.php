<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service;

/**
 * Class Google
 */
class Google extends \OAuth\OAuth2\Service\Google implements ServiceInterface
{
    
}
