<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service;

/**
 * Class Pinterest.
 */
class Pinterest extends \OAuth\OAuth2\Service\Pinterest implements ServiceInterface
{
    
}
