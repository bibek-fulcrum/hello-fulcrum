1.4.0
=============
* Added Paypal social provider

1.3.1
=============
* Fix Facebook deprecated data format

1.3.0
=============
* Added Vk social provider
* Added Odnoklassniki social provider

1.2.0
=============
* Added Pinterest social provider

1.1.1
=============
* Minor composer.json fix

1.1.0
=============
* Added Instagram social provider
* Minor improvements

1.0.0
=============
* Added initial version of Aheadworks SocialLogin
