<?php
namespace Aheadworks\SocialLogin\Block\Widget\Customer;

use Aheadworks\SocialLogin\Block\Customer\Login\Configurable;

/**
 * Class Login
 */
class Login extends Configurable implements \Magento\Widget\Block\BlockInterface
{

}
