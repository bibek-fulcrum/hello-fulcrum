<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service\Credentials;

/**
 * Interface CredentialsInterface
 */
interface CredentialsInterface extends \OAuth\Common\Consumer\CredentialsInterface
{

}
