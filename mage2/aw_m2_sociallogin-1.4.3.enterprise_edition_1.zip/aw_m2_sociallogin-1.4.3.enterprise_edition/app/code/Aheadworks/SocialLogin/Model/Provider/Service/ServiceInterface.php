<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service;

/**
 * Interface ServiceInterface
 */
interface ServiceInterface extends \OAuth\Common\Service\ServiceInterface
{

}
