<?php
namespace Aheadworks\SocialLogin\Model\Provider\RequestProcessor\Login;

use Aheadworks\SocialLogin\Model\Provider\RequestProcessor\Login;
use Aheadworks\SocialLogin\Model\Provider\Service\ServiceInterface;

/**
 * Class OAuth1 login processor
 */
abstract class OAuth1 extends Login
{

}
