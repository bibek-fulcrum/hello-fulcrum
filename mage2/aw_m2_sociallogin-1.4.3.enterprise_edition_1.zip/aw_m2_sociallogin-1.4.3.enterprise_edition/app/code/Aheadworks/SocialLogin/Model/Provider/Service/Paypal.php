<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service;

/**
 * Class Paypal.
 */
class Paypal extends \OAuth\OAuth2\Service\Paypal implements ServiceInterface
{

}
