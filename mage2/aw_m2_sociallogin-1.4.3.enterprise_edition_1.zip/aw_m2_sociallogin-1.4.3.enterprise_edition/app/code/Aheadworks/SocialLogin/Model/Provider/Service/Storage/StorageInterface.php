<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service\Storage;

use OAuth\Common\Storage\TokenStorageInterface;

/**
 * Interface StorageInterface
 */
interface StorageInterface extends TokenStorageInterface
{

}
