<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service;

/**
 * Class Twitter
 */
class Twitter extends \OAuth\OAuth1\Service\Twitter implements ServiceInterface
{

}
