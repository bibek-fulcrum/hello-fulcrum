<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service;

/**
 * Class LinkedIn
 */
class LinkedIn extends \OAuth\OAuth2\Service\Linkedin implements ServiceInterface
{
    
}
