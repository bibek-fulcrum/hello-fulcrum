<?php
namespace Aheadworks\SocialLogin\Model\Provider\Service;

/**
 * Class Instagram
 */
class Instagram extends \OAuth\OAuth2\Service\Instagram implements ServiceInterface
{
    
}
