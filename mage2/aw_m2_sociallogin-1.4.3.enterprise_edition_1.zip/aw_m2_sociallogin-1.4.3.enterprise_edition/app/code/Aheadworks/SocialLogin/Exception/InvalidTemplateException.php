<?php
namespace Aheadworks\SocialLogin\Exception;

use Magento\Framework\Exception\LocalizedException;

/**
 * Class InvalidTemplateException
 */
class InvalidTemplateException extends LocalizedException
{

}
