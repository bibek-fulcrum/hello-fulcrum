<?php
namespace Aheadworks\SocialLogin\Exception;

use Magento\Framework\Exception\LocalizedException;

/**
 * Class InvalidSocialAccountException
 */
class InvalidSocialAccountException extends LocalizedException
{

}
