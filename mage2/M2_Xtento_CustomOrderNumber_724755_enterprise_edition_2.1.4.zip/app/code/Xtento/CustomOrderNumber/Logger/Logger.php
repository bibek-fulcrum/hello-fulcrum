<?php

/**
 * Product:       Xtento_CustomOrderNumber (2.1.4)
 * ID:            Vqe1Nlt+QHcjmGhTx6IEBsWMPAIAPerLtUmPxDsEfQM=
 * Packaged:      2017-11-06T09:34:50+00:00
 * Last Modified: 2016-02-22T19:13:28+00:00
 * File:          app/code/Xtento/CustomOrderNumber/Logger/Logger.php
 * Copyright:     Copyright (c) 2017 XTENTO GmbH & Co. KG <info@xtento.com> / All rights reserved.
 */
namespace Xtento\CustomOrderNumber\Logger;

class Logger extends \Monolog\Logger
{
}