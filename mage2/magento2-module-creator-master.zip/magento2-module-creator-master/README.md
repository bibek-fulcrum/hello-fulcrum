# magento2-module-creator
Magento 2 Module Creator

<ul>
<li>This module creator script will save magento developers time which helps in providing estimation of custom module development.</li>
<li>To create a new module for Magento 2, insert Namespace and a Module name.</li>
<li>This script will create module which has basic folders, required PHP and XML files, frontend listing and view, backend listing and view according to Magento 2 structure and coding standards.</li>
<li>You can later start work by keeping/adding/removing/changing files according to your requirement.</li>
</ul>
