var config = {
    map: {
        '*': {
            'jquery/blockUI': 'Xtento_OrderExport/js/jquery/jquery.blockUI',
            'jquery/fileDownload': 'Xtento_OrderExport/js/jquery/jquery.fileDownload'
        }
    }
};